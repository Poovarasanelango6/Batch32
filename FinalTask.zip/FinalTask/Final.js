/* =========================================================
   EMPLOYEE MANAGEMENT DASHBOARD
   HTML + CSS + JavaScript (fetch, promises, array methods, DOM)
   ========================================================= */

/* ---------- Global state ---------- */
let employees = [];          // master array — every employee lives here
let currentDept = "All";     // active department filter
let currentSearch = "";      // active search text
let currentSort = "";        // active sort option
let nextId = 101;            // id counter for locally added employees

const API_URL = "https://dummyjson.com/users?limit=30";

/* The API returns departments like "Engineering", "Accounting", etc.
   The dashboard only uses four, so each API department is mapped to one. */
const DEPARTMENT_MAP = {
  "Engineering": "IT",
  "Support": "IT",
  "Services": "IT",
  "Research and Development": "IT",
  "Product Management": "IT",
  "Human Resources": "HR",
  "Training": "HR",
  "Accounting": "Finance",
  "Legal": "Finance",
  "Marketing": "Marketing",
  "Sales": "Marketing",
  "Business Development": "Marketing"
};

/* ---------- Element references ---------- */
const listEl       = document.getElementById("employeeList");
const statusEl     = document.getElementById("status");
const countLabelEl = document.getElementById("countLabel");
const countValueEl = document.getElementById("countValue");
const totalSalaryEl= document.getElementById("totalSalary");
const avgSalaryEl  = document.getElementById("avgSalary");
const topNameEl    = document.getElementById("topName");
const topSalaryEl  = document.getElementById("topSalary");
const formErrorsEl = document.getElementById("formErrors");
const formSuccessEl= document.getElementById("formSuccess");

/* =========================================================
   1. FETCH EMPLOYEES FROM API
   ========================================================= */
function fetchEmployees() {
  statusEl.className = "";
  statusEl.textContent = "Loading employees...";

  fetch(API_URL)
    .then(function (response) {
      if (!response.ok) {
        throw new Error("Request failed with status " + response.status);
      }
      return response.json();                 // convert response to JSON
    })
    .then(function (data) {
      // data.users is an array of objects — convert each one to our own shape
      data.users.forEach(function (user) {
        employees.push(createEmployeeFromApi(user));
      });

      statusEl.className = "success";
      statusEl.textContent = "Employee data loaded successfully.";
      displayEmployees();
    })
    .catch(function (error) {
      console.error(error);
      statusEl.className = "error";
      statusEl.textContent = "Unable to load employee data. Please try again.";
      displayEmployees();                     // still show any added employees
    })
    .finally(function () {
      console.log("API call finished. Employees in array:", employees.length);
    });
}

/* Convert one API user object into an employee object */
function createEmployeeFromApi(user) {
  const apiDept = user.company ? user.company.department : "";
  return {
    id: user.id,
    name: user.firstName + " " + user.lastName,
    age: user.age,
    email: user.email,
    phone: user.phone,
    department: DEPARTMENT_MAP[apiDept] || "IT",
    image: user.image,
    salary: buildSalary(user)                 // API has no salary, so derive one
  };
}

/* A simple, repeatable salary so the dashboard totals have real numbers */
function buildSalary(user) {
  return 30000 + (user.age * 800) + ((user.id % 7) * 3000);
}

/* =========================================================
   2. DISPLAY EMPLOYEES
   ========================================================= */
function displayEmployees() {
  const visible = getVisibleEmployees();

  listEl.innerHTML = "";                      // clear old cards

  if (visible.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "No employees match this search or filter.";
    listEl.appendChild(empty);
  } else {
    visible.forEach(function (emp) {
      listEl.appendChild(createEmployeeCard(emp));
    });
  }

  updateEmployeeCount(visible);
  calculateSalary(visible);
  showHighestPaid(visible);
}

/* Build one employee card with createElement + DOM methods */
function createEmployeeCard(emp) {
  const card = document.createElement("div");
  card.className = "emp-card";

  const img = document.createElement("img");
  img.src = emp.image || "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E";
  img.alt = emp.name;
  card.appendChild(img);

  const name = document.createElement("h3");
  name.textContent = emp.name;
  card.appendChild(name);

  const badge = document.createElement("span");
  badge.className = "badge";
  badge.textContent = emp.department;
  card.appendChild(badge);

  const details = document.createElement("div");
  details.innerHTML =
    "<p>Age: " + emp.age + "</p>" +
    "<p>Email: " + emp.email + "</p>" +
    "<p>Phone: " + (emp.phone || "—") + "</p>" +
    "<p class='salary'>Salary: " + formatRupees(emp.salary) + "</p>";
  card.appendChild(details);

  const delBtn = document.createElement("button");
  delBtn.className = "delete-btn";
  delBtn.textContent = "Delete";
  delBtn.addEventListener("click", function () {
    deleteEmployee(emp.id);
  });
  card.appendChild(delBtn);

  return card;
}

/* =========================================================
   3. SEARCH + FILTER + SORT (combined into one visible list)
   ========================================================= */
function getVisibleEmployees() {
  let result = employees;

  result = filterDepartment(result, currentDept);
  result = searchEmployees(result, currentSearch);
  result = sortEmployees(result, currentSort);

  return result;
}

function searchEmployees(list, text) {
  if (text === "") return list;
  const query = text.toLowerCase();
  return list.filter(function (emp) {
    return emp.name.toLowerCase().includes(query);
  });
}

function filterDepartment(list, dept) {
  if (dept === "All") return list;
  return list.filter(function (emp) {
    return emp.department === dept;
  });
}

function sortEmployees(list, option) {
  const copy = list.slice();                  // copy so the master array is untouched

  if (option === "name-asc")  return copy.sort(function (a, b) { return a.name.localeCompare(b.name); });
  if (option === "name-desc") return copy.sort(function (a, b) { return b.name.localeCompare(a.name); });
  if (option === "age-asc")   return copy.sort(function (a, b) { return a.age - b.age; });
  if (option === "age-desc")  return copy.sort(function (a, b) { return b.age - a.age; });
  if (option === "salary-asc")  return copy.sort(function (a, b) { return a.salary - b.salary; });
  if (option === "salary-desc") return copy.sort(function (a, b) { return b.salary - a.salary; });

  return copy;
}

/* =========================================================
   4. COUNT + SALARY DASHBOARD
   ========================================================= */
function updateEmployeeCount(visible) {
  countLabelEl.textContent = (currentDept === "All") ? "Total Employees" : currentDept + " Employees";
  countValueEl.textContent = visible.length;
}

function calculateSalary(visible) {
  const total = visible.reduce(function (sum, emp) {
    return sum + emp.salary;
  }, 0);

  const average = visible.length > 0 ? Math.round(total / visible.length) : 0;

  totalSalaryEl.textContent = formatRupees(total);
  avgSalaryEl.textContent = formatRupees(average);
}

function showHighestPaid(visible) {
  if (visible.length === 0) {
    topNameEl.textContent = "—";
    topSalaryEl.textContent = "";
    return;
  }

  const top = visible.reduce(function (highest, emp) {
    return emp.salary > highest.salary ? emp : highest;
  });

  topNameEl.textContent = top.name;
  topSalaryEl.textContent = formatRupees(top.salary);
}

function formatRupees(amount) {
  return "₹" + Number(amount).toLocaleString("en-IN");
}

/* =========================================================
   5. ADD EMPLOYEE (with validation)
   ========================================================= */
function addEmployee() {
  const name   = document.getElementById("nameInput").value.trim();
  const age    = document.getElementById("ageInput").value.trim();
  const email  = document.getElementById("emailInput").value.trim();
  const dept   = document.getElementById("deptInput").value;
  const salary = document.getElementById("salaryInput").value.trim();
  const phone  = document.getElementById("phoneInput").value.trim();

  const errors = validateEmployee(name, age, email, dept, salary);

  formSuccessEl.textContent = "";
  formErrorsEl.innerHTML = "";

  if (errors.length > 0) {
    errors.forEach(function (message) {
      const line = document.createElement("div");
      line.textContent = "❌ " + message;
      formErrorsEl.appendChild(line);
    });
    return;                                   // stop — do not add the employee
  }

  const newEmployee = {
    id: nextId,
    name: name,
    age: Number(age),
    email: email,
    phone: phone,
    department: dept,
    image: "",
    salary: Number(salary)
  };
  nextId = nextId + 1;

  employees.push(newEmployee);

  formSuccessEl.textContent = "✅ " + name + " added to " + dept + ".";
  clearForm();
  displayEmployees();
}

function validateEmployee(name, age, email, dept, salary) {
  const errors = [];

  if (name === "") {
    errors.push("Please enter employee name");
  }
  if (age === "" || Number(age) <= 18) {
    errors.push("Age must be greater than 18");
  }
  if (email === "") {
    errors.push("Please enter employee email");
  } else if (!email.includes("@") || !email.includes(".")) {
    errors.push("Please enter a valid email address");
  }
  if (dept === "") {
    errors.push("Please select a department");
  }
  if (salary === "" || Number(salary) <= 0) {
    errors.push("Please enter a salary greater than 0");
  }

  return errors;
}

function clearForm() {
  document.getElementById("nameInput").value = "";
  document.getElementById("ageInput").value = "";
  document.getElementById("emailInput").value = "";
  document.getElementById("deptInput").value = "";
  document.getElementById("salaryInput").value = "";
  document.getElementById("phoneInput").value = "";
}

/* =========================================================
   6. DELETE EMPLOYEE
   ========================================================= */
function deleteEmployee(id) {
  employees = employees.filter(function (emp) {
    return emp.id !== id;
  });
  displayEmployees();
}

/* =========================================================
   7. DATE AND TIME
   ========================================================= */
function showDateTime() {
  const months = ["January","February","March","April","May","June",
                  "July","August","September","October","November","December"];
  const now = new Date();

  const date  = now.getDate();
  const month = months[now.getMonth()];
  const year  = now.getFullYear();

  let hours = now.getHours();
  const minutes = now.getMinutes();
  const period = hours >= 12 ? "PM" : "AM";

  hours = hours % 12;
  if (hours === 0) hours = 12;

  document.getElementById("todayDate").textContent = date + " " + month + " " + year;
  document.getElementById("todayTime").textContent =
    padZero(hours) + ":" + padZero(minutes) + " " + period;
}

function padZero(value) {
  return value < 10 ? "0" + value : String(value);
}

/* =========================================================
   8. EVENT LISTENERS
   ========================================================= */
document.getElementById("searchBtn").addEventListener("click", function () {
  currentSearch = document.getElementById("searchInput").value.trim();
  displayEmployees();
});

document.getElementById("searchInput").addEventListener("keyup", function (event) {
  currentSearch = event.target.value.trim();  // live search while typing
  displayEmployees();
});

document.getElementById("sortSelect").addEventListener("change", function (event) {
  currentSort = event.target.value;
  displayEmployees();
});

document.querySelectorAll(".dept-btn").forEach(function (button) {
  button.addEventListener("click", function () {
    currentDept = button.dataset.dept;

    document.querySelectorAll(".dept-btn").forEach(function (b) {
      b.classList.remove("active");
    });
    button.classList.add("active");

    displayEmployees();
  });
});

document.getElementById("addBtn").addEventListener("click", addEmployee);

/* =========================================================
   9. START THE APP
   ========================================================= */
showDateTime();
setInterval(showDateTime, 1000);
fetchEmployees();